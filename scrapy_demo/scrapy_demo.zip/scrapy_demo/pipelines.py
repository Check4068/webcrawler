# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
import json


class ScrapyDemoPipeline(object):

    def __init__(self):
        self.fh = open("items.txt", "w")


    def process_item(self, item, spider):
        print(item["cardName"])
        print(item["enName"])
        print(item["jpName"])
        print(item["imgId"])
        print(item["rare"])
        print(item["cardNumber"])

        print("-----------")

        if len(item["rare"].split(',')) > 1:
            for u in item["rare"].split(','):
                self.fh.write("INSERT INTO `new_monster` VALUES("+'null'+',\''
                              +item["cardNumber"]+"\',\'" +"20PP -Premium pack"+"\',\'" +item["cardName"]+"\',\'" +item["enName"] +"\',\'"
                                               +item["jpName"]+"\',\'"+item["cardName"]+"\',\'" + item["imgId"] +"\',\'"+u + '\')；'+"\n")

        else:
            self.fh.write("INSERT INTO `new_monster` VALUES("+'null'+',\''
                              + item["cardNumber"] + "\',\'" + "20PP -Premium pack" + "\',\'" + item[
                              "cardName"] + "\',\'" + item["enName"] + "\',\'"
                          + item["jpName"]+"\',\'"+item["cardName"]+ "\',\'" + item["imgId"] + "\',\'"+ item["rare"] + '\')；'+"\n")
        return item
        '''
        i=1
        self.fh.write("INSERT INTO `new_monster` VALUES("+"i"+"item['cardName']"+"item['jpName']"+"item['enName']"+"item['cardName']","item['imgId']","item['imgId']+'.jpg') "+')'+"\n")
        i=i+1
        return item
        '''
def close_spider(self, spider):
    self.fh.close()