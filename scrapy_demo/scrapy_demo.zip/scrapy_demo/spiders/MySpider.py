import scrapy
from scrapy_demo.CardItems import CardItem
from scrapy.http import Request
from selenium import webdriver


class MySpider(scrapy.Spider):
    name = "MySpider"
    allowed_domains = []


    def __init__(self):
        self.browser = webdriver.Chrome()
        self.browser.set_page_load_timeout(30)

    def closed(self, spider):
        print("spider closed")
        self.browser.close()

    def start_requests(self):
        start_urls = ["http://www.qi-wmcard.com/card/20PP-JP001/"]
        for url in start_urls:
            yield Request(url, callback=self.parse)

    def parse(self, response):
        # 将我们得到的数据封装到一个 `MyspiderItem` 对象
        item = CardItem()
        #item["cardName"] = "card"
        #item["imgId"] = "1257564"
        #item["rare"] = "mormal"
        # 提取数据

        item["cardName"] = response.xpath('//span[contains(text(),"中文名称")]/parent::td/following-sibling::td/text()').extract()[0].strip().replace("\n","")
        item["enName"] = response.xpath('//span[contains(text(),"英文名称")]/parent::td/following-sibling::td/text()').extract()[0].strip().replace("\n", "")
        item["jpName"] = response.xpath('//span[contains(text(),"日文名称")]/parent::td/following-sibling::td/text()').extract()[0].strip().replace("\n", "")
        item["imgId"] = response.xpath('//span[contains(text(),"卡片密码")]/parent::td/following-sibling::td/text()').extract()[0].strip().replace("\n","")
        item["rare"] = response.xpath('//span[contains(text(),"稀有度")]/parent::td/following-sibling::td/text()').extract()[0].strip().replace("\n","")
        item["cardNumber"]=response.xpath('//span[contains(text(),"卡片编号")]/parent::td/following-sibling::td/text()').extract()[0].strip().replace("\n","")

        print(item["cardName"])
        print(item["enName"])
        print(item["jpName"])
        print(item["imgId"])
        print(item["rare"])
        # 将获取的数据交给pipelines
        yield item

        for u in range(20, 1,-1):
            if len(str(u))==1:
                url = "http://www.qi-wmcard.com/card/20PP-JP00" + str(u)
            else:
                url = "http://www.qi-wmcard.com/card/20PP-JP0" + str(u)
            yield Request(url, callback=self.parse)

